import os
os.system("docker build . -t backend3")